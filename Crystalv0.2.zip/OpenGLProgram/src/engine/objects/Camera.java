package engine.objects;

import engine.maths.MathsUtils;
import engine.maths.Matrix4f;
import engine.maths.Vector3f;
import engine.maths.Vector4f;

import org.lwjgl.glfw.GLFW;

import engine.io.Input;
import engine.io.Window;

public class Camera {
	public Vector3f position, rotation;
	private float moveSpeed = 0.25f;
	private float mouseSensitivity = 0.25f, scrollSensitivity = 1f;
	private double oldMouseX = 0, oldMouseY = 0;
	private double mouseX = 0, mouseY = 0;
	private float distance = 5.0f, horizontalAngle = 0f, verticalAngle = 0f;
	public Camera(Vector3f position, Vector3f rotation) {
		this.position = position;
		this.rotation = rotation;
	}
	public void editorupdate() {
		position = new Vector3f(0,60,0);
		rotation = new Vector3f(0,-90,-90);
	}
	public void update() {
		
		mouseX = Input.getMouseX();
		mouseY = Input.getMouseY();
		float x = (float) Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
		float z = (float) Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;
		if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { position = Vector3f.add(position, new Vector3f(z, 0, -x));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { position = Vector3f.add(position, new Vector3f(-z, 0, x));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT)) { position = Vector3f.add(position, new Vector3f(0, -moveSpeed, 0));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) { position = Vector3f.add(position, new Vector3f(0, moveSpeed, 0));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_W)) { position = Vector3f.add(position, new Vector3f(-x, 0, -z));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_S)) { position = Vector3f.add(position, new Vector3f(x, 0, z));}
		
		float dx = (float) (mouseX - oldMouseX);
		float dy = (float) (mouseY - oldMouseY);
		oldMouseX = mouseX;
		oldMouseY = mouseY;
		
		
		rotation = Vector3f.add(rotation, new Vector3f(-dy * mouseSensitivity, -dx * mouseSensitivity, 0));
		//System.out.println(rotation.getX() + " " + rotation.getY() + " " + rotation.getZ());
	}
	public void update(GameObject object) {
		mouseX = Input.getMouseX();
		mouseY = Input.getMouseY();
		
		float x = (float) Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
		float z = (float) Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;
		float dx = 0;
		float dy = 0;
		if (Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_MIDDLE)){
			dx = (float) (mouseX - oldMouseX);
		 	dy = (float) (mouseY - oldMouseY);
		}
		

		//if (Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_MIDDLE)) {
			verticalAngle -= (dy * mouseSensitivity);
			horizontalAngle += dx * mouseSensitivity;
		//}
			//System.out.println(verticalAngle);

			
			if (distance > 0) {
				distance = -((float) Input.getScrollY() * scrollSensitivity + 1);
				
			}else {
				distance = 0.2f;
				Input.setScrollY(-1.5);
			}

			float x1 = (float) Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
			float z1 = (float) Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;
			if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { object.position = Vector3f.add(object.position, new Vector3f(z1, 0, -x1));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { object.position = Vector3f.add(object.position, new Vector3f(-z1, 0, x1));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT)) { object.position = Vector3f.add(object.position, new Vector3f(0, -moveSpeed, 0));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) { object.position = Vector3f.add(object.position, new Vector3f(0, moveSpeed, 0));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_W)) { object.position = Vector3f.add(object.position, new Vector3f(-x1, 0, -z1));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_S)) { object.position = Vector3f.add(object.position, new Vector3f(x1, 0, z1));}
			
		float horizontalDistance = (float) (distance * Math.cos(Math.toRadians(verticalAngle)));
		float verticalDistance = (float) (distance * Math.sin(Math.toRadians(verticalAngle)));
		
		float xOffset = (float) (horizontalDistance * Math.sin(Math.toRadians(-horizontalAngle)));
		float zOffset = (float) (horizontalDistance * Math.cos(Math.toRadians(-horizontalAngle)));
		//if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { position = Vector3f.add(position, new Vector3f(z, 0, -x));}
		//if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { position = Vector3f.add(position, new Vector3f(-z, 0, x));}
		position.set(object.getPosition().getX() + xOffset, object.getPosition().getY() - verticalDistance, object.getPosition().getZ() + zOffset);
		rotation.set(verticalAngle,-horizontalAngle,0);
		
		oldMouseX = mouseX;
		oldMouseY = mouseY;
		
	}
	public Vector3f raycast(Window window, float WIDTH, float HEIGHT) {
		double mouseX = Input.getMouseX();
		double mouseY = Input.getMouseY();
		float x = (float)(2.0f * mouseX) / WIDTH - 1.0f;
		float y = (float)(1.0f - (2.0f * mouseY) / HEIGHT);
		float z = 1.0f;
		Vector3f ray_nds = new Vector3f(x, y, z);


		Vector4f ray_clip = new Vector4f(ray_nds.getX(), ray_nds.getY(), -1.0f, 1.0f);
		//Vector4f ray_eye = new Vector4f(window.getProjectionMatrix().invert() * ray_clip);
		
		//window.getProjectionMatrix().readOut();
		 window.getProjectionMatrix().invert();
		Vector4f ray_eye = Matrix4f.vectorMultiply(window.getProjectionMatrix().invert(), ray_clip);
		ray_eye = new Vector4f(ray_eye.getX(), ray_eye.getY(), -1.0f, 0.0f);
		Vector4f temp = Matrix4f.vectorMultiply(Matrix4f.view(this.getPosition(), this.getRotation()).invert(), ray_eye);
		Vector3f ray_world = new Vector3f(temp.getX(), temp.getY(), temp.getZ());
		
		//System.out.println("X: " + MathsUtils.round(ray_world.getX()) + " Y: " + MathsUtils.round(ray_world.getY()) + " Z: " + MathsUtils.round(ray_world.getZ()));
		return ray_world;
	}
	public Vector3f getPosition() {
		return position;
	}
	public Vector3f getRotation() {
		return rotation;
	}
	
}
