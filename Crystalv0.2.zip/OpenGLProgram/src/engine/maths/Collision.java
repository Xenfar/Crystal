package engine.maths;

import engine.graphics.Mesh;
import engine.objects.GameObject;

public class Collision {
	public static void checkCollisionClick(Vector3f origin, Vector3f direction, float distance, BoundingCube object) {
		Vector3f[] points = new Vector3f[50];
		System.out.println("-----------------------");
		Vector3f[] colPoints = object.getVerts();
		for (int i = 0; i < points.length; i++) {
			points[i] = Vector3f.multiply(origin, Vector3f.multiply(direction, i/distance));
			//points[i].readOut();
			
			if (points[i].getX() > colPoints[0].getX() && points[i].getY() > colPoints[0].getY() && points[i].getZ() > colPoints[0].getZ()) {
				System.out.println("bruh momento");
			}
			
			
		}
	}
}
