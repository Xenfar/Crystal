package engine.maths;

import engine.graphics.Vertex;

public class BoundingCube {
	private Vector3f[] vertices = new Vector3f[8];
	
	public BoundingCube(Vector3f[] verts) {
		vertices = verts;
	}
	public BoundingCube(Vector3f one, Vector3f two, Vector3f three, Vector3f four, Vector3f five, Vector3f six, Vector3f seven, Vector3f eight) {
		vertices[0] = one;
		vertices[1] = two;
		vertices[2] = three;
		vertices[3] = four;
		vertices[4] = five;
		vertices[5] = six;
		vertices[6] = seven;
		vertices[7] = eight;
	}
	public Vector3f[] getVerts() {
		return vertices;
	}
	
}
