package engine.graphics;

import engine.maths.Vector2f;
import engine.maths.Vector3f;

public class Vertex {
	private Vector3f position;
	private Vector2f textureCoord;
	private Vector3f normal;
	public Vector3f color;
	public Vertex(Vector3f position, Vector3f normal, Vector2f texCoord) {
		this.position = position;
		this.normal = normal;
		this.textureCoord = texCoord;
	}
	
	public Vector3f getPosition() {
		return position;
	}
	public Vector3f getNormal() {
		return normal;
	}
	public Vector2f getTextureCoord() {
		return textureCoord;
	}
	public Vector3f getColor() {
		return color;
	}
	public void setColor(Vector3f color2) {
		color = color2;
		
	}
}
