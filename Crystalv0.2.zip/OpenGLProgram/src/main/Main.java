package main;


import org.lwjgl.glfw.GLFW;


import engine.graphics.Material;
import engine.graphics.Mesh;
import engine.graphics.Renderer;
import engine.graphics.Shader;
import engine.graphics.Vertex;
import engine.io.Input;
import engine.io.ModelLoader;
import engine.io.Window;
import engine.maths.BoundingCube;
import engine.maths.Collision;
import engine.maths.Matrix4f;
import engine.maths.Vector2f;
import engine.maths.Vector3f;
import engine.maths.Vector4f;
import engine.objects.Camera;
import engine.objects.GameObject;
public class Main implements Runnable {
	public Thread game;
    public Window window;
    public Renderer renderer;
    public Shader shader;
    public Shader lineShader;
    public final int WIDTH = 800, HEIGHT = 800;
    
    public Mesh cubeMesh = ModelLoader.loadModel("resources/models/cup.obj", "/textures/teapottex.png", new Vector3f(1f,0.62f,0f));
    public Mesh planeMesh = ModelLoader.loadModel("resources/models/plane.obj", "/textures/Grass 1.png", new Vector3f(1f,0.62f,0f));
    //public Mesh sideMesh = ModelLoader.loadModel("resources/models/monke.fbx", "");
    public GameObject[] objects = new GameObject[2];
    public GameObject object = new GameObject(new Vector3f(0,1,0),new Vector3f(0,0,0),new Vector3f(1,1,1), cubeMesh, true);
	public Camera camera = new Camera(new Vector3f(0,0,1), new Vector3f(0,0,0));
	Renderer selRenderer;
    public void start() {
	game = new Thread(this, "game");
	
	game.start();
	
	}
	public void init() {
		System.out.println("game started");
		window = new Window(WIDTH, HEIGHT, "Game");
		shader = new Shader("/shaders/mainVertex.glsl", "/shaders/mainFragment.glsl");
		//window.setFullscreen(true);
		window.setBackgroundColour(0.2f, 0.4f, 0.7f);
		window.Create();
		renderer = new Renderer(window, shader);
		cubeMesh.create();
		//planeMesh.colorOverride = 1f;
		planeMesh.create();
		
		shader.create();
		lineShader = new Shader("/shaders/lineVertex.glsl", "/shaders/lineFragment.glsl");
		selRenderer = new Renderer(window, lineShader);
		lineShader.create();
		objects[0] = object;
		objects[1] = new GameObject(new Vector3f(0f,10f,0f),new Vector3f(0,0,0), new Vector3f(20,0,20), planeMesh, false);
		//objects[2] = new GameObject(new Vector3f(0f,1f,0f), new Vector3f(0,0,0), new Vector3f(20,20,20), sideMesh, false);
		object.objectActive = true;

	}
	Boolean isTransforming = false;
	Boolean isScaling = false;
	Boolean isRotating = false;
	//0 = all, 1 = x, 2 = y, 3 = z
	int moveMode = 0;
	double startPosX;
	double startPosY;
	float moveSensitivity = 7.5f;
	Vector3f startScale;
	Vector3f startPosition;
	Vector3f startRot;
	int selected = 0;
	public void run() {
		init();
		while(!window.shouldClose() && !Input.isKeyDown(GLFW.GLFW_KEY_ESCAPE)) {
			update();
			render();
			
			if (Input.isKeyDown(GLFW.GLFW_KEY_F11)) {
				window.setFullscreen(!window.isFullscreen());
			}
			if (Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_LEFT)) {
				//window.mouseState(true);
				
			}
				

			//Manipulate selected object's position, rotation and scale.
			attributeManipulation();
			//save movement
			if (Input.isKeyDown(GLFW.GLFW_KEY_ENTER)) {
				isTransforming = false;
				isScaling = false;
				isRotating = false;
				moveMode = 0;
			}
			//cancel movement
			if (Input.isKeyDown(GLFW.GLFW_KEY_BACKSPACE)) {

				isTransforming = false;
				isScaling = false;
				isRotating = false;
				// i have no clue why the scale and rotation resetting crashes the program
				//object.scale = startScale;
				object.position = startPosition;
				//object.rotation = startRot;
				moveMode = 0;
			}
			if (Input.isKeyDown(GLFW.GLFW_KEY_M)) {

					camera.position = new Vector3f(0,10,10);
					camera.rotation = new Vector3f(0,0,0);
					print("2");
					camSwitch = 2;
				

			}
			if (Input.isKeyDown(GLFW.GLFW_KEY_N)) {

				camSwitch = 3;
				print("3");
				
				
			}
			if (Input.isKeyDown(GLFW.GLFW_KEY_B)) {

					camSwitch = 1;
					print("1");
					
					
				
			}
			if (Input.isKeyDown(GLFW.GLFW_KEY_RIGHT)) {
				if (objects.length > selected + 1)
				selected += 1;
			}
			if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT)) {
				if (selected - 1 > -1)
				selected -= 1;
			}
		}
		close();
	}
	public void attributeManipulation() {
		if (Input.isKeyDown(GLFW.GLFW_KEY_P)) {
			startPosition = object.getPosition();
			startPosX = Input.getMouseX();
			startPosY = Input.getMouseY();
			isTransforming = true;
		}
		//Scaling enabling
		if (Input.isKeyDown(GLFW.GLFW_KEY_S) && Input.isKeyDown(GLFW.GLFW_KEY_LEFT_CONTROL)) {
			startScale = object.getScale();
			startPosX = Input.getMouseX();
			startPosY = Input.getMouseY();
			isScaling = true;
		}
		if (Input.isKeyDown(GLFW.GLFW_KEY_R)) {
			startRot = object.getRotation();
			startPosX = Input.getMouseX();
			startPosY = Input.getMouseY();
			isRotating = true;
		}
		if (Input.isKeyDown(GLFW.GLFW_KEY_X)) {
			moveMode = 1;

		}
		if (Input.isKeyDown(GLFW.GLFW_KEY_Y)) {
			moveMode = 2;

		}
		if (Input.isKeyDown(GLFW.GLFW_KEY_Z)) {
			moveMode = 3;

		}
		double curPosX = Input.getMouseX();
		double curPosY = Input.getMouseY();
		double distX = (curPosX - startPosX) / moveSensitivity;
		double distY = (curPosY - startPosY) / moveSensitivity;
		double distZ = ((curPosX + curPosY) - (startPosX + startPosY)) / moveSensitivity;
		if (isTransforming) {

			if (moveMode == 0) {
				if (camSwitch != 3) {
					Vector3f temp = new Vector3f((float)distX, -(float)distY, object.position.getZ());
					object.position = temp;
				}else {
					Vector3f temp = new Vector3f((float)distX, -(float)distY, (float)distZ);
					object.position = temp;
				}
				print("All manipulation");
			}
			if (moveMode == 1) {
				Vector3f temp = new Vector3f((float)distX, object.position.getY(), object.position.getZ());
				object.position = temp;
			}
			if (moveMode == 2) {
				Vector3f temp = new Vector3f(object.position.getX(), (float)-distY, object.position.getZ());
				object.position = temp;
			}
			if (moveMode == 3) {
				Vector3f temp = new Vector3f(object.position.getX(), object.position.getY(), (float)distZ);
				object.position = temp;
			}
			

		}
		if (isScaling) {
			if (moveMode == 0) {
				Vector3f temp = new Vector3f(-(float)distZ,(float)distZ, -(float)distZ);
				object.scale = temp;

			}
			if (moveMode == 1) {
				Vector3f temp = new Vector3f(1 + -(float)distX, object.scale.getY(), object.scale.getZ());
				object.scale = temp;
			}
			if (moveMode == 2) {
				Vector3f temp = new Vector3f(object.scale.getX(),1 + (float)distY, object.scale.getZ());
				object.scale = temp;

			}
			if (moveMode == 3) {
				Vector3f temp = new Vector3f(object.scale.getX(), object.scale.getY(), 1 + -(float)distZ);
				object.scale = temp;
			}
		}
		if (isRotating) {
			if (moveMode == 0) {
				Vector3f temp = new Vector3f((float)distX,(float)distY, (float)distZ);
				object.rotation = temp;

			}
			if (moveMode == 1) {
				Vector3f temp = new Vector3f((float)distX, object.scale.getY(), object.scale.getZ());
				object.rotation = temp;
			}
			if (moveMode == 2) {
				Vector3f temp = new Vector3f(object.scale.getX(),-(float)distY, object.scale.getZ());
				object.rotation = temp;

			}
			if (moveMode == 3) {
				Vector3f temp = new Vector3f(object.scale.getX(), object.scale.getY(), (float)distZ);
				object.rotation = temp;
			}
		}
		

	}
	int camSwitch = 1;
	private void update() {
		
		window.update();

		if (camSwitch == 1) {
			camera.editorupdate();
		}
		if (camSwitch == 2 && !isTransforming && !isScaling && !isRotating) {
			camera.update();
		}
		if (camSwitch == 3 && !isTransforming && !isScaling && !isRotating) {
			camera.update(object);

		}
		Vector3f[] cube = new Vector3f[] {
				new Vector3f(-2,-2,-2), new Vector3f(2,-2,2), new Vector3f(-2,-2,2), new Vector3f(2,-2,-2), new Vector3f(-2,2,-2), new Vector3f(2,2,2), new Vector3f(-2,2,2), new Vector3f(2,2,-2), 
		};
		//window.setCursorPos(WIDTH/2, HEIGHT/2);
		if (Input.isKeyDown(GLFW.GLFW_KEY_ENTER)) {
			Vector3f temp = camera.raycast(window, WIDTH, HEIGHT);
			Collision.checkCollisionClick(camera.position, temp, 10, new BoundingCube(cube));
		}

		//System.out.println("X: " + temp.getX() + " Y: + " + temp.getY() + " Z: " + temp.getZ());
		//if (!CheckCollision(object, objects[1])) {
			//object.update();
	//	}
		
		//for(int i = 0; i < objects.length; i++) {
			Vertex[] verts = objects[1].getMesh().getVertices();
			for(int a = 0; a < verts.length; a++) {
				//System.out.println("X: " + verts[a].getPosition().getX() + "Y: " + verts[a].getPosition().getY() + "Z: " + verts[a].getPosition().getZ());
			}

		//}

		
	}

	private void render() {
		if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) {
			selRenderer.renderLines(objects[1], camera, camera.raycast(window, WIDTH, HEIGHT));
		}

		selRenderer.renderSelected(objects[selected], camera);
		//renderer.renderLines(objects[1], camera);
		for(int i = 0; i < objects.length; i++) {
			renderer.renderMesh(objects[i], camera);
		}
		
		renderer.renderMesh(object, camera);
		
		window.swapBuffers();
	}
	private void close() {
		window.destroy();
		cubeMesh.destroy();
		planeMesh.destroy();
		//
		shader.destroy();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main().start();
	}
	public Boolean CheckCollision(GameObject one, GameObject two) // AABB - AABB collision
	{
	    // collision x-axis?
	    Boolean collisionX = one.getPosition().getX() + one.getScale().getX() >= two.getPosition().getX() &&
	        two.getPosition().getX() + two.getScale().getX() >= one.getPosition().getX();
	    // collision y-axis?
	    Boolean collisionY = one.getPosition().getY() + one.getScale().getY() >= two.getPosition().getY() &&
	        two.getPosition().getY() + two.getScale().getY() >= one.getPosition().getY();
	        
		    Boolean collisionZ = one.getPosition().getZ() + one.getScale().getZ() >= two.getPosition().getZ() &&
			        two.getPosition().getZ() + two.getScale().getZ() >= one.getPosition().getZ();
	    // collision only if on both axes
	    return collisionX && collisionZ;
	}  
	public void print(String p) {
		System.out.println(p);
	}

	

}
