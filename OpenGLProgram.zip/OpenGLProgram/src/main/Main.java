package main;


import org.lwjgl.glfw.GLFW;

import engine.graphics.Material;
import engine.graphics.Mesh;
import engine.graphics.Renderer;
import engine.graphics.Shader;
import engine.graphics.Vertex;
import engine.io.Input;
import engine.io.ModelLoader;
import engine.io.Window;
import engine.maths.Vector2f;
import engine.maths.Vector3f;
import engine.objects.Camera;
import engine.objects.GameObject;
public class Main implements Runnable {
	public Thread game;
    public Window window;
    public Renderer renderer;
    public Shader shader;
    public final int WIDTH = 800, HEIGHT = 800;
    
    public Mesh cubeMesh = ModelLoader.loadModel("resources/models/cup.obj", "/textures/teapottex.png");
    public Mesh planeMesh = ModelLoader.loadModel("resources/models/plane.obj", "/textures/Grass 1.png");
    //public Mesh sideMesh = ModelLoader.loadModel("resources/models/monke.fbx", "");
    public GameObject[] objects = new GameObject[2];
    public GameObject object = new GameObject(new Vector3f(0,1,0),new Vector3f(0,0,0),new Vector3f(1,1,1), cubeMesh, true);
	public Camera camera = new Camera(new Vector3f(0,0,1), new Vector3f(0,0,0));
    public void start() {
	game = new Thread(this, "game");
	
	game.start();
	
	}
	public void init() {
		System.out.println("game started");
		window = new Window(WIDTH, HEIGHT, "Game");
		shader = new Shader("/shaders/mainVertex.glsl", "/shaders/mainFragment.glsl");
		//window.setFullscreen(true);
		window.setBackgroundColour(0.2f, 0.4f, 0.7f);

		window.Create();
		renderer = new Renderer(window, shader);
		cubeMesh.create();
		planeMesh.create();
		shader.create();
		objects[0] = object;
		objects[1] = new GameObject(new Vector3f(0f,10f,0f),new Vector3f(0,0,0), new Vector3f(20,0,20), planeMesh, false);
		//objects[2] = new GameObject(new Vector3f(0f,1f,0f), new Vector3f(0,0,0), new Vector3f(20,20,20), sideMesh, false);
		

	}
	public void run() {
		init();
		while(!window.shouldClose() && !Input.isKeyDown(GLFW.GLFW_KEY_ESCAPE)) {
			update();
			render();
			if (Input.isKeyDown(GLFW.GLFW_KEY_F11)) {
				window.setFullscreen(!window.isFullscreen());
			}
			if (Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_LEFT)) {
				window.mouseState(true);
				
			}

		}
		close();
	}
	
	private void update() {

		//System.out.println("updatin");
		window.update();
		
		camera.update(object);

		
		
	}
	private void render() {
		for(int i = 0; i < objects.length; i++) {
			renderer.renderMesh(objects[i], camera);
		}
		renderer.renderMesh(object, camera);
		window.swapBuffers();
	}
	private void close() {
		window.destroy();
		cubeMesh.destroy();
		planeMesh.destroy();
		//
		shader.destroy();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main().start();
	}
	public Boolean CheckCollision(GameObject one, GameObject two) // AABB - AABB collision
	{
	    // collision x-axis?
	    Boolean collisionX = one.getPosition().getX() + one.getScale().getX() >= two.getPosition().getX() &&
	        two.getPosition().getX() + two.getScale().getX() >= one.getPosition().getX();
	    // collision y-axis?
	    Boolean collisionY = one.getPosition().getY() + one.getScale().getY() >= two.getPosition().getY() &&
	        two.getPosition().getY() + two.getScale().getY() >= one.getPosition().getY();
	        
		    Boolean collisionZ = one.getPosition().getZ() + one.getScale().getZ() >= two.getPosition().getZ() &&
			        two.getPosition().getZ() + two.getScale().getZ() >= one.getPosition().getZ();
	    // collision only if on both axes
	    return collisionX && collisionY && collisionZ;
	}  

	

}
