package engine.objects;

import engine.maths.Vector3f;

import org.lwjgl.glfw.GLFW;

import engine.io.Input;

public class Camera {
	public Vector3f position, rotation;
	private float moveSpeed = 0.25f;
	private float mouseSensitivity = 0.25f, scrollSensitivity = 1f;
	private double oldMouseX = 0, oldMouseY = 0;
	private double mouseX = 0, mouseY = 0;
	private float distance = 5.0f, horizontalAngle = 0f, verticalAngle = 0f;
	public Camera(Vector3f position, Vector3f rotation) {
		this.position = position;
		this.rotation = rotation;
	}
	public void update() {
		mouseX = Input.getMouseX();
		mouseY = Input.getMouseY();
		float x = (float) Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
		float z = (float) Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;
		if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { position = Vector3f.add(position, new Vector3f(z, 0, -x));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { position = Vector3f.add(position, new Vector3f(-z, 0, x));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT)) { position = Vector3f.add(position, new Vector3f(0, -moveSpeed, 0));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) { position = Vector3f.add(position, new Vector3f(0, moveSpeed, 0));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_W)) { position = Vector3f.add(position, new Vector3f(-x, 0, -z));}
		if (Input.isKeyDown(GLFW.GLFW_KEY_S)) { position = Vector3f.add(position, new Vector3f(x, 0, z));}
		
		float dx = (float) (mouseX - oldMouseX);
		float dy = (float) (mouseY - oldMouseY);
		oldMouseX = mouseX;
		oldMouseY = mouseY;
		
		rotation = Vector3f.add(rotation, new Vector3f(-dy * mouseSensitivity, -dx * mouseSensitivity, 0));
	}
	public void update(GameObject object) {
		mouseX = Input.getMouseX();
		mouseY = Input.getMouseY();
		
		float x = (float) Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
		float z = (float) Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;

		
		float dx = (float) (mouseX - oldMouseX);
		float dy = (float) (mouseY - oldMouseY);

		//if (Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_MIDDLE)) {
			verticalAngle -= (dy * mouseSensitivity);
			horizontalAngle += dx * mouseSensitivity;
		//}
			//System.out.println(verticalAngle);

			
			if (distance > 0) {
				distance = -((float) Input.getScrollY() * scrollSensitivity + 1);
				
			}else {
				distance = 0.2f;
				Input.setScrollY(-1.5);
			}

			float x1 = (float) Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
			float z1 = (float) Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;
			if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { object.position = Vector3f.add(object.position, new Vector3f(z1, 0, -x1));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { object.position = Vector3f.add(object.position, new Vector3f(-z1, 0, x1));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT)) { object.position = Vector3f.add(object.position, new Vector3f(0, -moveSpeed, 0));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) { object.position = Vector3f.add(object.position, new Vector3f(0, moveSpeed, 0));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_W)) { object.position = Vector3f.add(object.position, new Vector3f(-x1, 0, -z1));}
			if (Input.isKeyDown(GLFW.GLFW_KEY_S)) { object.position = Vector3f.add(object.position, new Vector3f(x1, 0, z1));}
			
		float horizontalDistance = (float) (distance * Math.cos(Math.toRadians(verticalAngle)));
		float verticalDistance = (float) (distance * Math.sin(Math.toRadians(verticalAngle)));
		
		float xOffset = (float) (horizontalDistance * Math.sin(Math.toRadians(-horizontalAngle)));
		float zOffset = (float) (horizontalDistance * Math.cos(Math.toRadians(-horizontalAngle)));
		//if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { position = Vector3f.add(position, new Vector3f(z, 0, -x));}
		//if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { position = Vector3f.add(position, new Vector3f(-z, 0, x));}
		position.set(object.getPosition().getX() + xOffset, object.getPosition().getY() - verticalDistance, object.getPosition().getZ() + zOffset);
		rotation.set(verticalAngle,-horizontalAngle,0);
		
		oldMouseX = mouseX;
		oldMouseY = mouseY;
		
	}
	public Vector3f getPosition() {
		return position;
	}
	public Vector3f getRotation() {
		return rotation;
	}
	
}
